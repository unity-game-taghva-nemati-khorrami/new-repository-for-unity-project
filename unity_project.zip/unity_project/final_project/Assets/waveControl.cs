﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class waveControl : MonoBehaviour
{
    public Transform enemy;

    public Transform positionOfEnemy;

    public float timer=5;

    private int waveNumber = 0;
    // Start is called before the first frame update
    void Start()
    {
        
        
        
    }

    // Update is called once per frame
    void Update()
    {
        if (timer <= 0.0f)
        {
            makeEnemy();
            timer = 5;
        }

        timer -= Time.deltaTime;
    }

    void makeEnemy()
    {
        for (int i = 0; i < waveNumber; i++)
        {
            Instantiate(enemy, positionOfEnemy.position, positionOfEnemy.rotation);
        }
        waveNumber++;
    }
}
