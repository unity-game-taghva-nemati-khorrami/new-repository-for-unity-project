﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class following_way : MonoBehaviour
{
    private Transform target;
    private Vector3 dir;
    private int nextindex;
    public float speed =10F;
    // Start is called before the first frame update
    void Start()
    {
        nextindex = 0;
        target = waypoint_script.points[0];
    }

    // Update is called once per frame
    void Update()
    {
        
        dir = target.position - transform.position;
            transform.Translate(dir.normalized*speed*Time.deltaTime);
            if (Vector3.Distance(transform.position, target.position) <= 0.2f)
            {
                nextindex++;
                if (nextindex >= waypoint_script.points.Length)
                {
                    Destroy(gameObject);
                    Debug.Log("fine");
                    return;
                }
                target = waypoint_script.points[nextindex];  
                Debug.Log(nextindex);
            }

            
        
    }
}
